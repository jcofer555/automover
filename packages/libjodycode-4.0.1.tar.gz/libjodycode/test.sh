#!/bin/sh

# This is a dummy test script meant for automated builds to succeed.
echo "OK"
